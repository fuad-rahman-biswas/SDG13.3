package newassigment1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.util.ArrayList;

class SDG13Goal {
    private String target;
    private String description;

    public SDG13Goal(String target, String description) {
        this.target = target;
        this.description = description;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

class User {
    private String username;
    private String password;
    private boolean isAdmin;

    public User(String username, String password, boolean isAdmin) {
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public boolean isAdmin() {
        return isAdmin;
    }
}

public class SDG13App {
    private ArrayList<SDG13Goal> goals;
    private ArrayList<User> users;
    private User currentUser;

    // GUI components
    private JFrame frame;
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public SDG13App() {
        goals = new ArrayList<>();
        users = new ArrayList<>();

        goals.add(new SDG13Goal("Strengthen resilience to climate hazards",
                "Improve resilience and adaptive capacity to climate-related disasters."));
        goals.add(new SDG13Goal("Integrate climate measures into policies",
                "Integrate measures into national policies, strategies, and planning."));
        goals.add(new SDG13Goal("Improve education on climate change",
                "Enhance education and awareness on climate change mitigation and adaptation."));
        goals.add(new SDG13Goal("Mobilize $100 billion annually",
                "Mobilize funds to address the needs of developing countries for climate actions."));
        goals.add(new SDG13Goal("Promote effective climate change planning",
                "Raise capacity for effective planning and management in least developed countries."));

        users.add(new User("HOUSIXIAN", "HSX818", true)); // Admin user
        users.add(new User("888", "888", false)); // Regular user

        // Initialize GUI components
        frame = new JFrame("SDG 13 Climate Action Application");
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Setup GUI
        setupLoginPanel();
        setupRegisterPanel();
        setupMainPanel();

        frame.add(mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600); // Larger interaction page
        frame.setVisible(true);
    }

    private void setupLoginPanel() {
        BackgroundPanel loginPanel = new BackgroundPanel("C:/Users/HWT/Documents/NetBeansProjects/SDG13App/image/main_background.jpg"); // Use background image
        loginPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Component spacing
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        Font font = new Font("Arial", Font.BOLD, 20);
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setFont(font);
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(font);
        usernameField.setFont(font);
        passwordField.setFont(font);
        loginButton.setFont(font);
        registerButton.setFont(font);

        gbc.gridx = 0;
        gbc.gridy = 0;
        loginPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        loginPanel.add(usernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        loginPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        loginPanel.add(passwordField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        loginPanel.add(loginButton, gbc);
        gbc.gridx = 1;
        loginPanel.add(registerButton, gbc);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                currentUser = getUserByUsername(username);
                if (currentUser != null && password.equals(currentUser.getPassword())) {
                    JOptionPane.showMessageDialog(frame, "Login successful.");
                    cardLayout.show(mainPanel, "main");
                } else {
                    JOptionPane.showMessageDialog(frame, "Login failed. Invalid username or password.");
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "register");
            }
        });

        mainPanel.add(loginPanel, "login");
    }

    private void setupRegisterPanel() {
        BackgroundPanel registerPanel = new BackgroundPanel("C:/Users/HWT/Documents/NetBeansProjects/SDG13App/image/main_background.jpg"); // Use background image
        registerPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Component spacing
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel usernameLabel = new JLabel("New Username:");
        JTextField usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("New Password:");
        JPasswordField passwordField = new JPasswordField();
        JLabel adminLabel = new JLabel("Are you an admin?");
        JCheckBox adminCheckBox = new JCheckBox();
        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        Font font = new Font("Arial", Font.BOLD, 20);
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setFont(font);
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(font);
        adminLabel.setForeground(Color.WHITE);
        adminLabel.setFont(font);
        usernameField.setFont(font);
        passwordField.setFont(font);
        adminCheckBox.setFont(font);
        registerButton.setFont(font);
        backButton.setFont(font);

        gbc.gridx = 0;
        gbc.gridy = 0;
        registerPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        registerPanel.add(usernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        registerPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        registerPanel.add(passwordField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        registerPanel.add(adminLabel, gbc);
        gbc.gridx = 1;
        registerPanel.add(adminCheckBox, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        registerPanel.add(registerButton, gbc);
        gbc.gridx = 1;
        registerPanel.add(backButton, gbc);

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                boolean isAdmin = adminCheckBox.isSelected();

                if (getUserByUsername(username) == null) {
                    users.add(new User(username, password, isAdmin));
                    JOptionPane.showMessageDialog(frame, "Registration successful. You can now log in.");
                    cardLayout.show(mainPanel, "login");
                } else {
                    JOptionPane.showMessageDialog(frame, "Username already exists. Registration failed.");
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "login");
            }
        });

        mainPanel.add(registerPanel, "register");
    }

    private void setupMainPanel() {
        BackgroundPanel mainMenuPanel = new BackgroundPanel("C:/Users/HWT/Documents/NetBeansProjects/SDG13App/image/main_background.jpg"); // Use background image
        mainMenuPanel.setLayout(new GridBagLayout()); // Use GridBagLayout for better control over spacing and alignment

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Component spacing

        JButton quickSearchButton = new JButton("Quick Search");
        JButton typhoonDosButton = new JButton("Typhoons Season Dos & Don'ts");
        JButton assistanceButton = new JButton("Assistance Center");
        JButton globlewarmingButton = new JButton("Globle Warming");
        JButton educationResourceButton = new JButton("Education Resource");
        JButton ABOUT = new JButton("ABOUT");
        JButton logoutButton = new JButton("Logout");

        Font font = new Font("Arial", Font.BOLD, 20);
        quickSearchButton.setFont(font);
        typhoonDosButton.setFont(font);
        assistanceButton.setFont(font);
        globlewarmingButton.setFont(font);
        educationResourceButton.setFont(font);
        ABOUT.setFont(font);
        logoutButton.setFont(font);

        quickSearchButton.setBackground(Color.LIGHT_GRAY);
        typhoonDosButton.setBackground(Color.LIGHT_GRAY);
        assistanceButton.setBackground(Color.LIGHT_GRAY);
        globlewarmingButton.setBackground(Color.LIGHT_GRAY);
        educationResourceButton.setBackground(Color.LIGHT_GRAY);
        ABOUT.setBackground(Color.LIGHT_GRAY);
        logoutButton.setBackground(Color.LIGHT_GRAY);

        gbc.gridx = 0;
        gbc.gridy = 0;
        mainMenuPanel.add(quickSearchButton, gbc);
        gbc.gridx = 1;
        mainMenuPanel.add(typhoonDosButton, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        mainMenuPanel.add(assistanceButton, gbc);
        gbc.gridx = 1;
        mainMenuPanel.add(globlewarmingButton, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainMenuPanel.add(educationResourceButton, gbc);
        gbc.gridx = 1;
        mainMenuPanel.add(ABOUT, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        mainMenuPanel.add(logoutButton, gbc);

        quickSearchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.example.com")); // Replace with actual URL
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        typhoonDosButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.example.com")); // Replace with actual URL
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        assistanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.example.com")); // Replace with actual URL
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        globlewarmingButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("1. Sea Level Rise\n" +
"Climate warming leads to the melting of glaciers and polar ice caps, as well as the thermal expansion of seawater, causing sea levels to rise. This can inundate low-lying coastal areas, threatening the habitats of millions of people, particularly those living on small islands and in coastal regions.\n" +
"\n" +
"2. Increase in Extreme Weather Events\n" +
"Climate warming increases the frequency and intensity of extreme weather events such as heatwaves, heavy rainfall, hurricanes, and droughts. These extreme events cause significant property damage, loss of life, and disruptions to agriculture, infrastructure, and economic activities.\n" +
"\n" +
"3. Damage to Ecosystems and Biodiversity\n" +
"Climate warming alters habitats, putting many species at risk of extinction. For example, coral bleaching is caused by rising sea temperatures, severely affecting marine biodiversity. Terrestrial species may also be forced to migrate or face extinction due to changing habitats.")); // Replace with actual URL
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        educationResourceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://lixuye67.wixsite.com/the-education-sour-2")); // Replace with actual URL
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        ABOUT.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://lixuye67.wixsite.com/sdg13")); // Replace with actual URL
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentUser = null;
                cardLayout.show(mainPanel, "login");
            }
        });

        mainPanel.add(mainMenuPanel, "main");
    }

    private User getUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        new SDG13App();
    }
}

class BackgroundPanel extends JPanel {
    private Image backgroundImage;

    public BackgroundPanel(String fileName) {
        try {
            backgroundImage = new ImageIcon(fileName).getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}






String[] questions = {
            "1. 以下哪项是世界上最高的山峰？",
            "2. 以下哪项是世界上最长的河流？",
            "3. 以下哪项是世界上最深的湖泊？",
            "4. 以下哪项是最大的沙漠？",
            "5. 以下哪项是世界上面积最大的国家？",
            "6. 以下哪项是世界上人口最多的城市？",
            "7. 以下哪项是世界上最古老的文明之一？",
            "8. 以下哪项是世界上最大的海洋？",
            "9. 以下哪项是世界上最长的铁路？",
            "10. 以下哪项是世界上最冷的地方？"
        };
        String[][] options = {
            {"A. 珠穆朗玛峰", "B. 乞力马扎罗山", "C. 洛杉矶山", "D. 富士山"},
            {"A. 亚马逊河", "B. 尼罗河", "C. 长江", "D. 密西西比河"},
            {"A. 贝加尔湖", "B. 里海", "C. 密歇根湖", "D. 五大湖"},
            {"A. 撒哈拉沙漠", "B. 阿拉伯沙漠", "C. 戈壁沙漠", "D. 大维多利亚沙漠"},
            {"A. 加拿大", "B. 俄罗斯", "C. 中国", "D. 美国"},
            {"A. 东京", "B. 上海", "C. 纽约", "D. 孟买"},
            {"A. 古埃及", "B. 古巴比伦", "C. 古希腊", "D. 古罗马"},
            {"A. 大西洋", "B. 印度洋", "C. 北冰洋", "D. 太平洋"},
            {"A. 西伯利亚铁路", "B. 泛美公路", "C. 长江铁路", "D. 亚欧大陆桥"},
            {"A. 南极洲", "B. 格陵兰", "C. 西伯利亚", "D. 阿拉斯加"}   
        };
        int[] correctAnswers = {0, 1, 0, 0, 1, 0, 0,3,0,0}; // 正确答案的索引

        int score = 0;

        // 遍历每道选择题
        for (int i = 0; i < questions.length; i++) {
            int response = JOptionPane.showOptionDialog(
                    null,                             // 父组件
                    questions[i],                     // 问题内容
                    "选择题 " + (i + 1),               // 对话框标题
                    JOptionPane.DEFAULT_OPTION,       // 选项类型
                    JOptionPane.QUESTION_MESSAGE,     // 消息类型
                    null,                             // 图标（可以是null）
                    options[i],                       // 选项按钮
                    options[i][0]                     // 默认选中的选项
            );

            // 检查用户的选择是否正确
            if (response == correctAnswers[i]) {
                JOptionPane.showMessageDialog(null, "正确答案！");
                score++;
            }else {
                String correctOption = options[i][correctAnswers[i]];
                JOptionPane.showMessageDialog(null, "错误答案。正确答案是: " + correctOption);
            }
        }

        // 显示最终得分
        JOptionPane.showMessageDialog(null, "你总共答对了 " + score + " 道题。");
        int sum=score*10;
        JOptionPane.showMessageDialog(null, "你总共得了 " + sum + " marks");
        // Implement viewing and adding climate data logic for public users
        // ...
    }else {
            JOptionPane.showMessageDialog(null, "Invalid credentials. Access denied.");
        }
    }
    
    private static void editorUserActions() {
        String inputUsername = JOptionPane.showInputDialog("Enter your username (Other):");
        String inputPassword = JOptionPane.showInputDialog("Enter your password (Other):");
        if (inputUsername.equals(editorUsername) && inputPassword.equals(editorPassword)) {
            String[] adminOptions = {"View climate data", "edit climate data",};
            int adminChoice = JOptionPane.showOptionDialog(
                    null,
                    "Choose an action:",
                    "Government User Actions",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    adminOptions,
                    null
            );
            JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JLabel existingLabel = new JLabel("这是已有的内容：");
        JTextField existingField = new JTextField(10);
        existingField.setText("已有的值");
        
        JLabel additionalLabel = new JLabel("这是新添加的内容：");
        JTextField additionalField = new JTextField(10);

        panel.add(existingLabel);
        panel.add(existingField);
        panel.add(additionalLabel);
        panel.add(additionalField);

        int result = JOptionPane.showConfirmDialog(null, panel, "复杂内容对话框", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String existingValue = existingField.getText();
            String additionalValue = additionalField.getText();
            JOptionPane.showMessageDialog(null, "已有的值: " + existingValue + "\n新添加的值: " + additionalValue);
        } else {
            JOptionPane.showMessageDialog(null, "操作已取消。");
        }
    
        // Implement viewing and adding climate data logic for public users
        // ...
    }else {
            JOptionPane.showMessageDialog(null, "Invalid credentials. Access denied.");
        }
    }
        // Implement editing any existing climate data logic for other users
        // ...
    }
